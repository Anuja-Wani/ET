var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1024" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1594301579244.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1594301579244-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1594301579244-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-both devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="ET" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1594301579244.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1594301579244-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1594301579244-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="1360px" datasizeheight="1917px" dataX="0" dataY="-53"   alt="image">\
          <img src="./images/be8f1c40-6df5-414c-80d2-b8ea4d45003f.png" />\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="169px" datasizeheight="20px" dataX="32" dataY="209" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Name of the Company</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="92px" datasizeheight="20px" dataX="32" dataY="314" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">Founding By</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_1" class="nativedropdown firer ie-background commentable non-processed"    datasizewidth="301px" datasizeheight="30px" dataX="27" dataY="350"  tabindex="-1"><div class="valign"><div class="value"></div></div><div class="icon"></div><select id="s-Category_1-options" class="s-d12245cc-1680-458d-89dd-4f0d7fb22724 dropdown-options" ><option selected="selected" class="option"><br /></option>\
      <option  class="option">You</option>\
      <option  class="option">A current member of your research group</option>\
      <option  class="option">A former member of your research group</option></select></div>\
      <div id="s-Paragraph_9" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="208px" datasizeheight="20px" dataX="31" dataY="415" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0">Number of Employees (FTE) </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_10" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="304px" datasizeheight="20px" dataX="27" dataY="523" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_10_0">Describe company&#039;s products or services</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_11" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="130px" datasizeheight="20px" dataX="27" dataY="725" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_11_0">Licensed UMD IP?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_12" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="250px" datasizeheight="20px" dataX="28" dataY="826" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_12_0">Federal or state funding received</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_2" class="nativedropdown firer ie-background commentable non-processed"    datasizewidth="180px" datasizeheight="20px" dataX="27" dataY="767"  tabindex="-1"><div class="valign"><div class="value"></div></div><div class="icon"></div><select id="s-Category_2-options" class="s-d12245cc-1680-458d-89dd-4f0d7fb22724 dropdown-options" ><option selected="selected" class="option"><br /></option>\
      <option  class="option">Yes</option>\
      <option  class="option">No</option></select></div>\
      <div id="s-Category_3" class="pie radiobuttonlist firer commentable non-processed"    datasizewidth="180px" datasizeheight="83px" dataX="32" dataY="858"  tabindex="-1">\
        <div class="backgroundLayer"></div>\
        <div class="scroll">\
          <table class="collapse" style="height: 100%; width: 100%;" summary="">\
            <tbody>\
                <tr>\
                  <td>\
                      <input type="radio" name="s-Category_3"   tabindex="-1" /><span class="option">STTR</span>\
                  </td>\
                </tr>\
                <tr>\
                  <td>\
                      <input type="radio" name="s-Category_3"   tabindex="-1" /><span class="option">MIPS</span>\
                  </td>\
                </tr>\
            </tbody>\
          </table>\
        </div>\
      </div>\
      <div id="s-Paragraph_13" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="106px" datasizeheight="20px" dataX="32" dataY="984" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_13_0">Calendar year</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-TextArea" class="group firer ie-background commentable non-processed" datasizewidth="381px" datasizeheight="140px" dataX="28" dataY="561" >\
        <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="381px" datasizeheight="140px" dataX="0" dataY="0"   alt="image" systemName="./images/f257b40c-7e27-41d1-a24e-bb9e8ad295e9.svg" overlay="#B8BBBD">\
            <?xml version="1.0" encoding="utf-8"?>\
            <!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
            <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\
            <svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_2-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
            	 width="352.582px" height="252.625px" viewBox="0 0 352.582 252.625" enable-background="new 0 0 352.582 252.625"\
            	 xml:space="preserve">\
            <g>\
            	<g>\
            		<g>\
            			<path fill="#959A9D" d="M295.443,0.588C226.362,0.968,157.12,0.022,90.019,0.001c-29.881,0-59.596,0.001-88.619,0.001H0.042\
            				L0.043,1.36c0.056,85.3,0.109,168.591,0.163,250l0.001,1.195h1.193c97.771-0.06,192.771-0.07,285.166,0.133\
            				c14.161,0.016,37.46,0.041,51.981,0.058c30.165-0.087-0.327-1.603-14.762-1.815c-90.616-1.351-189.658-1.1-269.772-0.66\
            				c-17.56,0.08-35.11,0.16-52.614,0.238l0.854,0.854c-0.299-83.648-0.241-167.047-0.094-250L1.4,2.119\
            				c117.619,0.208,234.425,0.594,349.999,0.393l-1.151-1.152c0.126,72.621,0.483,144.75,1.264,216.297\
            				c0.107,9.891,0.543,51.729,1.054,24.805c0.521-27.563,0.156-82.114,0.104-94.054c-0.094-47.534-0.188-96.718-0.287-147.048\
            				l-0.002-0.985l-0.979,0.004C333.047,0.447,314.283,0.517,295.443,0.588z M320.175,0.975c-1.284-0.19,8.294-0.589,9.921-0.349\
            				C331.38,0.815,321.801,1.216,320.175,0.975z"/>\
            		</g>\
            	</g>\
            </g>\
            </svg>\
\
        </div>\
        <div id="s-Input_3" class="pie textarea firer focusin focusout mouseenter mouseleave commentable non-processed"  datasizewidth="372px" datasizeheight="135px" dataX="4" dataY="2" ><div class="backgroundLayer"></div><textarea   tabindex="-1" placeholder="Text Area"></textarea></div>\
      </div>\
      <div id="s-textInput" class="group firer ie-background commentable non-processed" datasizewidth="307px" datasizeheight="36px" dataX="32" dataY="1017" >\
        <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="307px" datasizeheight="36px" dataX="0" dataY="0"   alt="image" systemName="./images/fe17d52d-54e0-44c7-8471-6844e29925a7.svg" overlay="#B8BBBD">\
            <?xml version="1.0" encoding="utf-8"?>\
            <!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
            <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\
            <svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_3-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
            	 width="353.125px" height="40.75px" viewBox="0 0 353.125 40.75" enable-background="new 0 0 353.125 40.75" xml:space="preserve">\
            <g>\
            	<g>\
            		<g>\
            			<path fill="#959A9D" d="M191.648,0.603c-44.672,0.38-89.448-0.566-132.841-0.586c-19.336,0-38.563,0-57.307,0.001H0.142\
            				l0.001,1.357c0.009,12.943,0.02,25.593,0.027,38l0.001,1.331L1.5,40.705c107.399-0.096,210.007-0.334,308.074-0.004\
            				c9.157,0.031,24.225,0.099,33.614,0.058c19.507-0.087-0.212-1.602-9.545-1.815c-58.6-1.351-122.646-1.1-174.454-0.659\
            				C106.458,38.732,53.857,38.79,1.5,38.702l0.673,0.673c0.028-12.686,0.057-25.357,0.085-38L1.5,2.134\
            				c118.271,0.324,235.275,1.077,350-0.615l-0.145-0.144c0.085,5.424,0.17,10.817,0.255,16.205\
            				c0.108,6.396,0.543,33.452,1.054,16.041c0.247-8.436,0.296-20.779,0.271-32.246l-0.003-1.445L351.5-0.062\
            				c-12.797,0.075-24.51,0.144-28.576,0.168C280.732,0.388,236.527,0.222,191.648,0.603z M207.641,0.99\
            				c-0.831-0.19,5.363-0.589,6.416-0.349C214.887,0.83,208.693,1.23,207.641,0.99z"/>\
            		</g>\
            	</g>\
            </g>\
            </svg>\
\
        </div>\
        <div id="s-Input_4" class="pie text firer commentable non-processed"  datasizewidth="303px" datasizeheight="32px" dataX="3" dataY="3" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Text input"/></div></div>  </div></div>\
      </div>\
      <div id="s-textInput_1" class="group firer ie-background commentable non-processed" datasizewidth="353px" datasizeheight="41px" dataX="31" dataY="450" >\
        <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="353px" datasizeheight="41px" dataX="0" dataY="0"   alt="image" systemName="./images/f3cc79ad-c627-40a3-9fde-1b8b7a872688.svg" overlay="#B8BBBD">\
            <?xml version="1.0" encoding="utf-8"?>\
            <!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
            <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\
            <svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_4-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
            	 width="353.125px" height="40.75px" viewBox="0 0 353.125 40.75" enable-background="new 0 0 353.125 40.75" xml:space="preserve">\
            <g>\
            	<g>\
            		<g>\
            			<path fill="#959A9D" d="M191.648,0.603c-44.672,0.38-89.448-0.566-132.841-0.586c-19.336,0-38.563,0-57.307,0.001H0.142\
            				l0.001,1.357c0.009,12.943,0.02,25.593,0.027,38l0.001,1.331L1.5,40.705c107.399-0.096,210.007-0.334,308.074-0.004\
            				c9.157,0.031,24.225,0.099,33.614,0.058c19.507-0.087-0.212-1.602-9.545-1.815c-58.6-1.351-122.646-1.1-174.454-0.659\
            				C106.458,38.732,53.857,38.79,1.5,38.702l0.673,0.673c0.028-12.686,0.057-25.357,0.085-38L1.5,2.134\
            				c118.271,0.324,235.275,1.077,350-0.615l-0.145-0.144c0.085,5.424,0.17,10.817,0.255,16.205\
            				c0.108,6.396,0.543,33.452,1.054,16.041c0.247-8.436,0.296-20.779,0.271-32.246l-0.003-1.445L351.5-0.062\
            				c-12.797,0.075-24.51,0.144-28.576,0.168C280.732,0.388,236.527,0.222,191.648,0.603z M207.641,0.99\
            				c-0.831-0.19,5.363-0.589,6.416-0.349C214.887,0.83,208.693,1.23,207.641,0.99z"/>\
            		</g>\
            	</g>\
            </g>\
            </svg>\
\
        </div>\
        <div id="s-Input_2" class="pie text firer commentable non-processed"  datasizewidth="348px" datasizeheight="36px" dataX="3" dataY="3" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Text input"/></div></div>  </div></div>\
      </div>\
      <div id="s-textInput_2" class="group firer ie-background commentable non-processed" datasizewidth="353px" datasizeheight="41px" dataX="31" dataY="243" >\
        <div id="s-Image_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="353px" datasizeheight="41px" dataX="0" dataY="0"   alt="image" systemName="./images/53d7a725-e591-4a2d-bde5-029746e81f09.svg" overlay="#B8BBBD">\
            <?xml version="1.0" encoding="utf-8"?>\
            <!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
            <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\
            <svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_5-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
            	 width="353.125px" height="40.75px" viewBox="0 0 353.125 40.75" enable-background="new 0 0 353.125 40.75" xml:space="preserve">\
            <g>\
            	<g>\
            		<g>\
            			<path fill="#959A9D" d="M191.648,0.603c-44.672,0.38-89.448-0.566-132.841-0.586c-19.336,0-38.563,0-57.307,0.001H0.142\
            				l0.001,1.357c0.009,12.943,0.02,25.593,0.027,38l0.001,1.331L1.5,40.705c107.399-0.096,210.007-0.334,308.074-0.004\
            				c9.157,0.031,24.225,0.099,33.614,0.058c19.507-0.087-0.212-1.602-9.545-1.815c-58.6-1.351-122.646-1.1-174.454-0.659\
            				C106.458,38.732,53.857,38.79,1.5,38.702l0.673,0.673c0.028-12.686,0.057-25.357,0.085-38L1.5,2.134\
            				c118.271,0.324,235.275,1.077,350-0.615l-0.145-0.144c0.085,5.424,0.17,10.817,0.255,16.205\
            				c0.108,6.396,0.543,33.452,1.054,16.041c0.247-8.436,0.296-20.779,0.271-32.246l-0.003-1.445L351.5-0.062\
            				c-12.797,0.075-24.51,0.144-28.576,0.168C280.732,0.388,236.527,0.222,191.648,0.603z M207.641,0.99\
            				c-0.831-0.19,5.363-0.589,6.416-0.349C214.887,0.83,208.693,1.23,207.641,0.99z"/>\
            		</g>\
            	</g>\
            </g>\
            </svg>\
\
        </div>\
        <div id="s-Input_1" class="pie text firer commentable non-processed"  datasizewidth="348px" datasizeheight="36px" dataX="3" dataY="3" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Text input"/></div></div>  </div></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;