var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1024" deviceHeight="768">\
    <div id="t-ef07b413-721c-418e-81b1-33a7ed533245" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="960 grid - 12 columns" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/ef07b413-721c-418e-81b1-33a7ed533245-1594301579244.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/ef07b413-721c-418e-81b1-33a7ed533245-1594301579244-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/ef07b413-721c-418e-81b1-33a7ed533245-1594301579244-ie8.css" /><![endif]-->\
      <div id="t-Table_1" class="pie percentage table firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"  datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0" originalwidth="1024px" originalheight="768px" >\
        <div class="backgroundLayer"></div>\
        <table summary="">\
          <tbody>\
            <tr>\
              <td id="t-Cell_1" class="pie cellcontainer firer non-processed"    datasizewidth="86px" datasizeheight="768px" dataX="0" dataY="0" originalwidth="86px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_1 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
              <td id="t-Cell_2" class="pie cellcontainer firer non-processed"    datasizewidth="86px" datasizeheight="768px" dataX="80" dataY="0" originalwidth="86px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_2 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
              <td id="t-Cell_3" class="pie cellcontainer firer non-processed"    datasizewidth="86px" datasizeheight="768px" dataX="160" dataY="0" originalwidth="86px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_3 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
              <td id="t-Cell_4" class="pie cellcontainer firer non-processed"    datasizewidth="86px" datasizeheight="768px" dataX="240" dataY="0" originalwidth="86px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_4 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
              <td id="t-Cell_5" class="pie cellcontainer firer non-processed"    datasizewidth="85px" datasizeheight="768px" dataX="320" dataY="0" originalwidth="85px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_5 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
              <td id="t-Cell_6" class="pie cellcontainer firer non-processed"    datasizewidth="85px" datasizeheight="768px" dataX="400" dataY="0" originalwidth="85px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_6 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
              <td id="t-Cell_7" class="pie cellcontainer firer non-processed"    datasizewidth="85px" datasizeheight="768px" dataX="480" dataY="0" originalwidth="85px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_7 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
              <td id="t-Cell_8" class="pie cellcontainer firer non-processed"    datasizewidth="85px" datasizeheight="768px" dataX="560" dataY="0" originalwidth="85px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_8 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
              <td id="t-Cell_9" class="pie cellcontainer firer non-processed"    datasizewidth="85px" datasizeheight="768px" dataX="640" dataY="0" originalwidth="85px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_9 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
              <td id="t-Cell_10" class="pie cellcontainer firer non-processed"    datasizewidth="85px" datasizeheight="768px" dataX="720" dataY="0" originalwidth="85px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_10 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
              <td id="t-Cell_11" class="pie cellcontainer firer non-processed"    datasizewidth="85px" datasizeheight="768px" dataX="800" dataY="0" originalwidth="85px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_11 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
              <td id="t-Cell_12" class="pie cellcontainer firer non-processed"    datasizewidth="85px" datasizeheight="768px" dataX="880" dataY="0" originalwidth="85px" originalheight="768px" >\
                <div class="layout scrollable">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Cell_12 Table_1" valign="middle" align="center" hSpacing="0" vSpacing="0"></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </td>\
            </tr>\
          </tbody>\
        </table>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;